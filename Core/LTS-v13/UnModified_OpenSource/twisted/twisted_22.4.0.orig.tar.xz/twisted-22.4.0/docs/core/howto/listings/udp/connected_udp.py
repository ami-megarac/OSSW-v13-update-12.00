from twisted.internet import reactor
from twisted.internet.protocol import DatagramProtocol


class Helloer(DatagramProtocol):
    def startProtocol(self):
        host = "192.168.1.1"
        port = 1234

        self.transport.connect(host, port)
        print("now we can only send to host %s port %d" % (host, port))
        self.transport.write(b"hello")  # no need for address

    def datagramReceived(self, data, addr):
        print(f"received {data!r} from {addr}")

    # Possibly invoked if there is no server listening on the
    # address to which we are sending.
    def connectionRefused(self):
        print("No one listening")


# 0 means any port, we don't care in this case
reactor.listenUDP(0, Helloer())
reactor.run()
