# Installation
> `npm install --save @types/jquery`

# Summary
This package contains type definitions for jquery (https://jquery.com).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/jquery.

### Additional Details
 * Last updated: Thu, 24 Feb 2022 15:01:41 GMT
 * Dependencies: [@types/sizzle](https://npmjs.com/package/@types/sizzle)
 * Global values: `$`, `Symbol`, `jQuery`

# Credits
These definitions were written by [Leonard Thieu](https://github.com/leonard-thieu), [Boris Yankov](https://github.com/borisyankov), [Christian Hoffmeister](https://github.com/choffmeister), [Steve Fenton](https://github.com/Steve-Fenton), [Diullei Gomes](https://github.com/Diullei), [Tass Iliopoulos](https://github.com/tasoili), [Sean Hill](https://github.com/seanski), [Guus Goossens](https://github.com/Guuz), [Kelly Summerlin](https://github.com/ksummerlin), [Basarat Ali Syed](https://github.com/basarat), [Nicholas Wolverson](https://github.com/nwolverson), [Derek Cicerone](https://github.com/derekcicerone), [Andrew Gaspar](https://github.com/AndrewGaspar), [Seikichi Kondo](https://github.com/seikichi), [Benjamin Jackman](https://github.com/benjaminjackman), [Josh Strobl](https://github.com/JoshStrobl), [John Reilly](https://github.com/johnnyreilly), [Dick van den Brink](https://github.com/DickvdBrink), [Thomas Schulz](https://github.com/King2500), [Terry Mun](https://github.com/terrymun), [Martin Badin](https://github.com/martin-badin), and [Chris Frewin](https://github.com/princefishthrower).
