.. Copyright (C) Internet Systems Consortium, Inc. ("ISC")
..
.. SPDX-License-Identifier: MPL-2.0
..
.. This Source Code Form is subject to the terms of the Mozilla Public
.. License, v. 2.0.  If a copy of the MPL was not distributed with this
.. file, you can obtain one at https://mozilla.org/MPL/2.0/.
..
.. See the COPYRIGHT file distributed with this work for additional
.. information regarding copyright ownership.

.. _changelog:

Changelog
=========

.. note:: The following list contains detailed information about BIND 9
   development. Regular users should refer to :ref:`Release Notes <relnotes>`
   for changes relevant to them.

.. include:: ../changelog/changelog-9.18.49.rst
.. include:: ../changelog/changelog-9.18.48.rst
.. include:: ../changelog/changelog-9.18.47.rst
.. include:: ../changelog/changelog-9.18.46.rst
.. include:: ../changelog/changelog-9.18.45.rst
.. include:: ../changelog/changelog-9.18.44.rst
.. include:: ../changelog/changelog-9.18.43.rst
.. include:: ../changelog/changelog-9.18.42.rst
.. include:: ../changelog/changelog-9.18.41.rst
.. include:: ../changelog/changelog-9.18.40.rst
.. include:: ../changelog/changelog-9.18.39.rst
.. include:: ../changelog/changelog-9.18.38.rst
.. include:: ../changelog/changelog-9.18.37.rst
.. include:: ../changelog/changelog-9.18.36.rst
.. include:: ../changelog/changelog-9.18.35.rst
.. include:: ../changelog/changelog-9.18.34.rst
.. include:: ../changelog/changelog-9.18.33.rst
.. include:: ../changelog/changelog-9.18.32.rst
.. include:: ../changelog/changelog-9.18.31.rst
.. include:: ../changelog/changelog-9.18.30.rst
.. include:: ../changelog/changelog-9.18.29.rst
.. include:: ../changelog/changelog-history.rst
